import java.util.ArrayList;

public class BigNumber {
    
    ArrayList<Integer> number = new ArrayList<Integer>();
    
    public BigNumber(int input){
        int mod = 10;
        int remover = 0;
        while(true){
            number.add(input % mod);
            remover += input % mod;
            mod *= 10;
            if(input % mod == input){
                break;
            }
        }
    }
    
    //If something get's above ten.
    public void sort(){
        for(int i=0;i<number.size();i++){
            if(number.get(i)>=10){
                Integer factor = (number.get(i)-(number.get(i)%10))/10;
                number.set(i,(number.get(i))-(number.get(i)*factor));
                number.set(i+1,number.get(i+1)+factor);
            }
        }
    }
    
    public void add(int input){
        int mod = 10;
        int remover = 0;
        int iteration = 0;
        while(true){
            number.set(iteration,number.get(iteration) + (input % mod));
            remover += input % mod;
            mod *= 10;
            if(input % mod == input){
                break;
            }
        }
    }
    
    public String toString(){
        int result = 0;
        int pow = 1;
        for(int input: number){
            result = input*pow;
            pow *= 10;
        }
        return String.valueOf(result);
    }
    
}