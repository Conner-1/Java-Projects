import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class Real extends JPanel implements ActionListener, MouseListener {
    
    int boardWidth = 420;
    int boardHeight = 365;
    
    double generation = 0;
    double money = 0;
    
    Timer gameLoop;
    
    ArrayList<Button> buttonArray = new ArrayList<Button>();
    
    class Button {
        int x;
        int y;
        int width;
        int height;
        int cost;
        int gain;
        boolean active;
        
        Button (int x,int y, int width, int height, int cost, int gain, boolean active){
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.cost = cost;
            this.gain = gain;
            this.active = active;
        }
    }
    
    Real(){
        setPreferredSize(new Dimension(boardWidth,boardHeight));
        setBackground(Color.black);
        setFocusable(true);
        addMouseListener(this);
        
        int n1 = 0; int n2 = 1;
        //y values = i
        for(int i=0;i<4;i++){
            //x values = j
            for(int j=0;j<5;j++){
                //Space buttons per 80, 60x60
                int xMin = 20;
                int yMin = 20;
                Button button = new Button(xMin+j*80,yMin+i*80,60,60,n1,n2,true);
                n1 = (n1+5)*8;
                n2 = (n2)*8;
                buttonArray.add(button);
            }
        }
        
        gameLoop = new Timer(100, this);
        gameLoop.start();
    }
    
    public void ticks() {
        money += generation/10;
    }
    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }
    
    public void draw(Graphics g) {
        g.setColor(Color.white);
        g.drawRect(5,5,boardWidth-10,boardHeight-10);
        
        for (int i = 0; i < buttonArray.size(); i++) {
            Button button = buttonArray.get(i);
            if (button.active) {
                g.setColor(Color.white);
                g.drawRect(button.x, button.y, button.width, button.height);
                g.setColor(Color.green);
                g.drawString("GAIN: " , button.x+8,button.y+button.height-45);
                g.drawString(String.valueOf((int) button.gain),button.x+8,button.y+button.height-33);
                g.setColor(Color.red);
                g.drawString("COST: " , button.x+8,button.y+button.height-17);
                g.drawString(String.valueOf((int) button.cost),button.x+8,button.y+button.height-5);
            }
        }
        
        //score
        g.setColor(Color.white);
        g.setFont(new Font("Arial", Font.PLAIN, 32));
        g.drawString(String.valueOf((int) money), 10, boardHeight-10);
    }
    
    public boolean detectCollision(Button a, int x, int y){
        return  a.x < x && a.x + a.width > x && a.y < y && a.y + a.height > y;
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        ticks();
        repaint();
    }
    
    @Override 
    public void mouseEntered(MouseEvent e){}
    
    @Override
    public void mouseClicked(MouseEvent e){
        for (int i = 0; i < buttonArray.size(); i++) {
            Button button = buttonArray.get(i);
            if (detectCollision(button,e.getX(),e.getY())){
                if(button.cost<=money){
                    money -= button.cost;
                    generation += button.gain;
                }
            }
        }
    }
    
    @Override
    public void mouseReleased(MouseEvent e){}
    
    @Override 
    public void mousePressed(MouseEvent e){}
    
    @Override
    public void mouseExited(MouseEvent e){}
    
}