public class Simulation {
    //Any return -100 is the equivalence of a negative for what it's trying to do.
    
    static Animal[][] grid = new Animal[10][10];
    
    public Simulation(int[][] set) {
        for(int i=0;i<set.length;i++){
            for(int j=0;j<set[0].length;j++){
                int number = set[i][j];
                Animal animal = new Animal("Air",".");
                if(number == 0){
                    animal = new Animal("Air",".");
                } else if(number == 1){
                    animal = new Rabbit("Rabbit","R");
                }  else if(number == 2){
                    animal = new Wolf("Wolf","H");
                }
                grid[i][j] = animal;
            }
        }
    }
    
    public void simulate(int cycles){
        //HUNTER FIRST
        for(int z=0;z<cycles;z++){
            for(int y=0;y<grid.length;y++){
                for(int x=0;x<grid[0].length;x++){
                    if(grid[y][x].getSymbol().equals("H")){
                        //Since it's wolfs, it always seperates in collision with anything
                        //If predator, then it's anti collision, if prey, then hunting
                        if(grid[y][x].counter()==0){
                            remove(x,y);
                        } else {
                            //Returns [x,y], x = collums, y = rows
                            int[] decision = grid[y][x].decide(x,y);
                            
                            if(decision[0]!=-100){
                                int moveX = decision[0];
                                int moveY = decision[1];
                                
                                if(!(x+moveX<grid[0].length&&x+moveX>=0)&&y+moveY<grid.length&&y+moveY>=0){
                                    //If x out of bounds
                                    moveX *= -1;
                                } else if(!(y+moveY<grid.length&&y+moveY>=0)&&x+moveX<grid[0].length&&x+moveX>=0){
                                    //If y out of bounds
                                    moveY *= -1;
                                } else if(!(y+moveY<grid.length&&y+moveY>=0)&&!(x+moveX<grid[0].length&&x+moveX>=0)){
                                    //If both x and y out of bounds
                                    moveX *= -1;
                                    moveY *= -1;
                                }
                                if(x+moveX<grid[0].length&&x+moveX>=0&&y+moveY<grid.length&&y+moveY>=0){
                                    Animal entity = grid[y+moveY][x+moveX];
                                    if(entity.getSymbol().equals("R")){
                                        //System.out.println("Hunted Rabbit");
                                        Animal animal = grid[y][x];
                                        animal.setCounter(25);
                                        remove(x,y);
                                        remove(x+moveX,y+moveY);
                                        //Wolf's dupe automatically after killing Rabbits
                                        seperate(x,y,animal,animal);
                                    } else if(entity.equals(grid[y][x])){
                                        //If it collides, then just dont move
                                    } else {
                                        move(x,y,moveX,moveY,grid[y][x]);
                                    }
                                } else {
                                    move(x,y,moveX,moveY,grid[y][x]);
                                }
                            }
                        }
                    }
                }
            }
            //HUNTER TURN END
            
            
            //PREY SECOND
            for(int y=0;y<grid.length;y++){
                for(int x=0;x<grid[0].length;x++){
                    if(grid[y][x].getSymbol().equals("R")){
                        //If predator is within radius, run
                        //else keep colliding with rabbits, even if they don't
                        //have the counter down.
                        int[] decision = grid[y][x].decide(x,y);
                        if(decision[0]!=-100){
                            int moveX = decision[0];
                            int moveY = decision[1];
                            
                            //Maybe inefficient, but if zero, then do nothing
                            if(!(x+moveX<grid[0].length&&x+moveX>=0)&&y+moveY<grid.length&&y+moveY>=0){
                                //If x out of bounds
                                moveX *= -1;
                            } else if(!(y+moveY<grid.length&&y+moveY>=0)&&x+moveX<grid[0].length&&x+moveX>=0){
                                //If y out of bounds
                                moveY *= -1;
                            } else if(!(y+moveY<grid.length&&y+moveY>=0)&&!(x+moveX<grid[0].length&&x+moveX>=0)){
                                //If both x and y out of bounds
                                moveX *= -1;
                                moveY *= -1;
                            }
                            
                            Animal entity = grid[y+moveY][x+moveX];
                            Animal animal = grid[y][x];
                            if(entity.equals(animal)){
                                //Check if both are ready to reproduce, otherwise don't move
                                //Also checking if one the moveY and moveX variables are not 0 
                                if(entity.counter()<=0&&animal.counter()<=0&&(moveY!=0||moveX!=0)){
                                    animal.setCounter(5);
                                    remove(x,y);
                                    remove(x+moveX,y+moveY);
                                    duplicate(x,y);
                                }
                            } else if(entity.getSymbol().equals("H")){
                                //System.out.println("Rabbit Ran into wolf");
                                //After running into a Wolf, Rabbits are effectively
                                //Eaten
                                entity.setCounter(25);
                                remove(x,y);
                                remove(x+moveX,y+moveY);
                                //Wolf's dupe automatically after killing Rabbits
                                seperate(x,y,entity,entity);
                            } else {
                                move(x,y,moveX,moveY,grid[y][x]);
                            }
                        }
                    }
                }
            }
            //PREY TURN END
            //Prevent Animals from moving twice
            for(int y=0;y<grid.length;y++){
                for(int x=0;x<grid[0].length;x++){
                    grid[y][x].getReady();
                }
            }
        }
    }
    
    /*
    if r = 2, x = excluded
        0
      0 0 0
    0 0 x 0 0
      0 0 0
        0
    */
    public static int[] detectSurroundings(int x,int y, int r, String target){
        //String checkedCoords = "";
        
        for(int i=-r;i<=r;i++){
            int width = Math.abs(r-Math.abs(i));
            for(int j=-width;j<=width;j++){
                int pointY = y+i;
                int pointX = x+j;
                //checkedCoords += "(" + pointX + ", " + pointY + "), ";
                if(pointY>=0&&pointY<grid.length&&pointX>=0&&pointX<grid[0].length){
                    if(grid[pointY][pointX].getSymbol().equals(target)&&!(pointX == x&&pointY == y)){
                        //Not the precise coordinates
                        //If j is negative, then the target is to the left of the entity looking for the target
                        int[] coordinates = {j,i};
                        //System.out.println(coordinates[0] + " " + coordinates[1]);
                        //System.out.println(checkedCoords);
                        return coordinates;
                    }
                }
            }
        }
        //System.out.println(checkedCoords);
        int[] nothing = {-100};
        return nothing;
    }
    
    //For duplicate/seperate functions
    //They need to be deactivated before initialization into the grid to prevent multiple turns
    
    //Rabbits only, Animal object unrequired in parameters/argument
    public void duplicate(int x,int y){
        //System.out.println("Duplicating...");
        Animal entity = new Rabbit("Rabbit","R",5);
        entity.unready();
        move(x,y,0,-1,entity);
        entity = new Rabbit("Rabbit","R",5);
        entity.unready();
        move(x,y,0,1,entity);
        entity = new Rabbit("Rabbit","R",5);
        entity.unready();
        move(x,y,1,0,entity);
    }
    
    //To cover the fact there may be different counters with different times
    //I need two animal objects
    public void seperate(int x,int y, Animal animal, Animal entity){
        //System.out.println("Seperating...");
        Animal newAnimal;
        if(animal.getSymbol().equals("R")){
            newAnimal = new Rabbit("Rabbit","R",animal.counter());
        } else {
            newAnimal = new Wolf("Wolf","H",animal.counter());
        }
        Animal newEntity;
        if(entity.getSymbol().equals("R")){
            newEntity = new Rabbit("Rabbit","R",entity.counter());
        } else {
            newEntity = new Wolf("Wolf","H",entity.counter());
        }
        newAnimal.unready();
        newEntity.unready();
        move(x,y,0,-1,newAnimal);
        move(x,y,0,1,newEntity);
    }
    
    //Moved functionality to simulate, keeping these functions just in case
    public void move(int x,int y, int moveX,int moveY, Animal animal){
        //System.out.println("Trying to move: " + moveX + " " + moveY);
        if(moveX==0&&moveY==0){
            //If it randomly returns 0,0, then do nothing.
            return;
        }
        //Functions shouldn't be necessary with the simulate function doing these
        //Already
        if(x+moveX<grid[0].length&&x+moveX>=0&&y+moveY<grid.length&&y+moveY>=0){
            //If no out of bounds
            grid[y][x] = animal;
            add(x+moveX,y+moveY,animal);
            remove(x,y);
        } else if(!(x+moveX<grid[0].length&&x+moveX>=0)&&y+moveY<grid.length&&y+moveY>=0){
            //If x out of bounds
            grid[y][x] = animal;
            add(x-moveX,y+moveY,animal);
            remove(x,y);
        } else if(!(y+moveY<grid.length&&y+moveY>=0)&&x+moveX<grid[0].length&&x+moveX>=0){
            //If y out of bounds
            grid[y][x] = animal;
            add(x+moveX,y-moveY,animal);
            remove(x,y);
        } else {
            //If both x and y out of bounds
            grid[y][x] = animal;
            add(x-moveX,y-moveY,animal);
            remove(x,y);
        }
    }
    
    public void add(int x, int y, Animal animal){
        grid[y][x] = animal;
    }
    
    public void remove(int x, int y){
        grid[y][x] = new Animal("Air",".");
    }
    
    public String toString(){
        String word = " ";
        for(int i=0;i<grid.length;i++){
            for(int j=0;j<grid[0].length;j++){
                Animal animal = grid[i][j];
                word += animal.getSymbol() + "  ";
            }
            word += "\n ";
        }
        return word;
    }
}