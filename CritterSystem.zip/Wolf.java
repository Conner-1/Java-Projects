public class Wolf extends Animal{
    
    private String type;
    private String symbol;
    //Lifespan is 24-25 turns.
    
    public Wolf(String type, String symbol){
        super(type,symbol,25);
    }
    
    public Wolf(String type, String symbol, int counter){
        super(type,symbol,counter);
    }
    
    @Override
    public int[] decide(int x, int y){
        if(super.isReady()){
            super.countdown();
            super.unready();
            int[] checkR = Simulation.detectSurroundings(x,y,4,"R");
            if(checkR[0]!=-100){
                //System.out.println("Wolf Detected Rabbit");
                int moveX = 0;
                if(checkR[0]>0){
                    moveX = 1;
                } else if(checkR[0]<0){
                    moveX = -1;
                }
                int moveY = 0;
                if(checkR[1]>0){
                    moveY = 1;
                } else if(checkR[1]<0){
                    moveY = -1;
                }
                //System.out.println("Trying to Move to rabbit " + moveX + " " + moveY);
                int[] coordinates = {moveX,moveY};
                return coordinates;
            }
            //System.out.println("Wolf Moving Randomly");
            int moveX = (int)(Math.random()*3)-1;
            int moveY = (int)(Math.random()*3)-1;
            int[] coordinates = {moveX,moveY};
            return coordinates;
        } else {
            int[] nothing = {-100};
            return nothing;
        }
    }
    
}