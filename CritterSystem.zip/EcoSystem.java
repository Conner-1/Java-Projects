import java.util.Scanner;

/* Previous attempt was coded badly, went to sandbox
 * 
 * TO ADD
 * - Maybe remove rabbits ability to kill wolves entirely?
 * 
 * FIXED
 * - Fixed scanner radius
 * - Changed the Simulation.simulate(cycles) to Simulation.simulate(actualLoops)
 * - Fixed the bug that made animals move multiple times at once, duplicating on point
 * - Fixed issues coming from having no super classes previously, causing the Countdown timer to work
 * - Fixed anti collision mechanics by disabling movement
 * - Fixed Rabbits ability to kill hunters
*/
public class EcoSystem {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        //To quickly alter the location wolves/rabbits are
        int[][] set = {
            {0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,1,0},
            {0,0,1,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,1,0,0,0},
            {0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,1,0},
            {0,0,0,2,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,1,0,0},
            {0,1,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0}
        };
        
        //Initiallizing the grid that'll actually be used
        Simulation simulation = new Simulation(set);
        
        //Exist to have accurate cycle counter
        int cycles = 0;
        System.out.println("Press a number to Continue (Type [exit] to leave)");
        boolean exit = false;
        //While function to Prevent any form of possible errors forming from user input
        while(!exit){
            System.out.print("How many cycles should be simulated?: ");
            int actualLoops = 0;
            boolean yes = true;
            while(yes){
                yes = false;
                String loops = input.nextLine();
                if(loops.equals("exit")){
                    exit = true;
                    break;
                }
                //Checks if a user just put in enter
                if(loops.length()==0){
                    System.out.print("Try again (Type a # or 'exit', then enter) - ");
                    yes = true;
                }
                //Checks if a user put in too high of a #
                //Cuz the ten thousands are already too high
                if(loops.length()>4){
                    System.out.print("Try again (Too high) - ");
                    yes = true;
                }
                //Checks for any symbols used and if letters were used
                for(int i=0;i<loops.length();i++){
                    if(!(Character.isDigit(loops.charAt(i)))){
                        if(!yes)System.out.print("Try again (Type a # or 'exit') - ");
                        yes = true;
                    }
                }
                if(!yes)actualLoops = Integer.parseInt(loops);
            }
            cycles += actualLoops;
            simulation.simulate(actualLoops);
            System.out.println("---------- Cycle " + cycles + " ----------");
            System.out.println(simulation);
        }
    }
}