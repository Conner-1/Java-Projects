public class Animal {
    /* Have a decide class to bo overridden
     * Have it return int that means where they want to go
     * For the simulation, it'll do most of the work with the actual
     * grid being initiated inside it
     * 
    */
    
    /* Like the scrapped one
     * The decision for prey and hunter should be similar
     * Both wants to get to rabbits, either to eat them or to reproduce
     * The only difference is that prey should check for hunters
     * And run depending on where the hunter is
     * To find where Rabbits or Wolfs are, I suppose bringing in
     * The search area function is necessary
    */
    
    //Rabbits are unable to produce with a hunter nearby
    //Rabbits killing themselves in seperations/duplications are overpopulation
    
    
    //Hunters shouldn't die from rabbits seperating
    
    private String type;
    private String symbol;
    private int counter;
    private boolean ready = true;
    
    public Animal(String type, String symbol, int counter){
        this.type = type;
        this.symbol = symbol;
        this.counter = counter;
    }
    //For animals that don't exist
    public Animal(String type, String symbol){
        this.type = type;
        this.symbol = symbol;
    }
    
    public int[] decide(int x, int y){
        System.out.println("Error");
        //Nothing
        int[] nothing = {-100};
        return nothing;
    }
    
    public String getSymbol(){
        return symbol;
    }
    
    public boolean isReady(){
        return ready;
    }
    
    public String getType(){
        return type;
    }
    
    public void unready(){
        ready = false;
    }
    
    public void getReady(){
        ready = true;
    }
    
    //Don't Override
    public int counter(){
        return counter;
    }
    
    public void setCounter(int counter){
        this.counter = counter;
    }
    
    public void countdown(){
        if(counter>0)counter--;
    }
    
    public boolean equals(Animal other){
        return type.equals(other.getType());
    }
    
}