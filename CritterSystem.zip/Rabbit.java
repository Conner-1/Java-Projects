public class Rabbit extends Animal {
    
    private String type;
    private String symbol;
    //Time until ready to reproduce
    
    public Rabbit(String type, String symbol){
        super(type,symbol,0);
    }
    
    public Rabbit(String type, String symbol, int counter){
        super(type,symbol,counter);
    }
    
    @Override
    public int[] decide(int x, int y){
        if(super.isReady()){
            super.countdown();
            super.unready();
            int[] checkH = Simulation.detectSurroundings(x,y,2,"H");
            if(checkH[0]!=-100){
                //Redoing this important section
                //Moving away from the predator
                //System.out.println("Rabbit Found Wolf");
                int moveX = 0;
                if(checkH[0]>0){
                    moveX = -1;
                } else if(checkH[0]<0){
                    moveX = 1;
                }
                int moveY = 0;
                if(checkH[1]>0){
                    moveY = -1;
                } else if(checkH[1]<0){
                    moveY = 1;
                }
                //System.out.println("Trying to Move away from hunter " + moveX + " " + moveY);
                int[] coordinates = {moveX,moveY};
                return coordinates;
            }
            int[] checkR = Simulation.detectSurroundings(x,y,3,"R");
            //Making sure rabbits don't camp one spot and
            //Prevent any overlapping
            if(checkR[0]!=-100&&super.counter()<3){
                //System.out.println("Rabbit Found Rabbit");
                int moveX = 0;
                if(checkR[0]>0){
                    moveX = 1;
                } else if(checkR[0]<0){
                    moveX = -1;
                }
                int moveY = 0;
                if(checkR[1]>0){
                    moveY = 1;
                } else if(checkR[1]<0){
                    moveY = -1;
                }
                //System.out.println("Trying to Move to rabbit " + moveX + " " + moveY);
                int[] coordinates = {moveX,moveY};
                return coordinates;
            }
            //System.out.println("Rabbit Moving Randomly");
            //If nothing else, just move randomly one space
            //-1,0,1 are options
            int moveX = (int)(Math.random()*3)-1;
            int moveY = (int)(Math.random()*3)-1;
            int[] coordinates = {moveX,moveY};
            return coordinates;
        }
        int[] nothing = {-100};
        return nothing;
    }
}