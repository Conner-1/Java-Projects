// Project: The Java Graphics
// Track: The Physicist (Action/Arcade)
// Phase 1: The Prototype (Complete)
// Phase 2: The Core Logic (Complete)
// Phase 3: The Polish (Complete)

// Game Name: Endless Barfight!
// Author(s): Conner Yu and Hailey Ishida
// Credits : space-invaders.java - ImKennyYip - https://github.com/ImKennyYip/space-invaders-java

// Import Statements
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

//It acts as if it's a JPanel in the MyProgram (){} class thingeth, meaning size can be altered.
public class MyProgram extends JPanel implements ActionListener, KeyListener {
    //Place to add Frame size
    int boardWidth = 256;
    int boardHeight = 512;
    
    //Can add images and entity variables here, maybe make them final variables (no way)
    Image cowboyImg;
    Image bottleImg;
    Image bartenderImg;
    Image bartenderThrowImg;
    Image bulletImg;
    
    //cowboy entity/cowboy variables
    int cowboyWidth = 100;
    int cowboyHeight = 100;
    int cowboyX = boardWidth / 2 -cowboyWidth / 2;
    int cowboyY = boardHeight-cowboyHeight;
    int cowboyVelocityX = 25;
    Entity cowboy;
    
    //Bottle entity variables
    ArrayList<Entity> bottleArray;
    int bottleWidth = 70;
    int bottleHeight = 70;
    int bottleVelocityY = 6;
    int bottleCount = 0;
    
    //Bullet entity variables
    ArrayList<Entity> bulletArray;
    int bulletWidth = 5;
    int bulletHeight = 10;
    int bulletVelocityY = -10;
    
    Timer gameLoop;
    boolean gameOver = false;
    int score = 0;
    
    class Entity {
        int x;
        int y;
        int width;
        int height;
        Image img;
        
        boolean alive = true; // For the glass entities
        boolean hit = false; // For Gun Bollet
        
        Entity (int x,int y, int width, int height, Image img){
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.img = img;
        
        }
    }
    
    MyProgram() {
        setPreferredSize(new Dimension(boardWidth,boardHeight));
        setBackground(Color.black);
        setFocusable(true);
        addKeyListener(this);
        
        //add the images needed
        cowboyImg = new ImageIcon(getClass().getResource("./Cowboy.png")).getImage();
        bottleImg = new ImageIcon(getClass().getResource("./Bottle.png")).getImage();
        bartenderImg = new ImageIcon(getClass().getResource("./Bartender.png")).getImage();
        bartenderThrowImg = new ImageIcon(getClass().getResource("./Bartender_Throw.png")).getImage();
        bulletImg = new ImageIcon(getClass().getResource("./Bullet.png")).getImage();
        
        //Initiate cowboy entity and other entities
        cowboy = new Entity(cowboyX, cowboyY, cowboyWidth, cowboyHeight, cowboyImg);
        bottleArray = new ArrayList<Entity>();
        bulletArray = new ArrayList<Entity>();
        
        //Start timer/game loop
        gameLoop = new Timer(2000/60, this); //2000/60 = 33.2
        createBottle();
        gameLoop.start();
    }
    
    //draw functions I don't understand
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }
    
    public void draw(Graphics g) {
        //Background Border
        g.setColor(Color.white);
        g.drawRect(5,5,boardWidth-10,boardHeight-10);
        
        //cowboy
        g.drawImage(cowboy.img, cowboy.x, cowboy.y, cowboy.width, cowboy.height, null);
        
        //Bottle
        for (int i = 0; i < bottleArray.size(); i++) {
            Entity bottle = bottleArray.get(i);
            if (bottle.alive) {
                g.drawImage(bottle.img, bottle.x, bottle.y, bottle.width, bottle.height, null);
            }
        }

        //bullets
        g.setColor(Color.white);
        for (int i = 0; i < bulletArray.size(); i++) {
            Entity bullet = bulletArray.get(i);
            if (!bullet.hit) {
                g.drawRect(bullet.x, bullet.y, bullet.width, bullet.height);
                // g.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
            }
        }

        //score
        g.setColor(Color.white);
        g.setFont(new Font("Arial", Font.PLAIN, 32));
        if (gameOver) {
            g.drawString("Game Over: " + String.valueOf((int) score), 10, 35);
        }
        else {
            g.drawString(String.valueOf((int) score), 10, 35);
        }
    }
    
    //Move/The Function I usually call ticks
    public void ticks() {
        //bottle
        for (int i = 0; i < bottleArray.size(); i++) {
            Entity bottle = bottleArray.get(i);
            if (bottle.alive) {
                for (int j = 0; j < bottleArray.size(); j++) {
                    bottleArray.get(j).y += bottleVelocityY;
                }
                
                if (bottle.y >= cowboy.y) {
                    gameOver = true;
                }
                
            }
        }

        //bullets
        for (int i = 0; i < bulletArray.size(); i++) {
            Entity bullet = bulletArray.get(i);
            bullet.y += bulletVelocityY;

            //bullet collision with bottles
            for (int j = 0; j < bottleArray.size(); j++) {
                Entity bottle = bottleArray.get(j);
                if (!bullet.hit && bottle.alive && detectCollision(bullet, bottle)) {
                    bullet.hit = true;
                    bottle.alive = false;
                    bottleCount--;
                    score += 100;
                }
            }
        }

        //clear bullets
        while (bulletArray.size() > 0 && (bulletArray.get(0).hit || bulletArray.get(0).y < 0)) {
            bulletArray.remove(0); //removes the first element of the array
        }

        //next level
        if (bottleCount == 0) {
            //increase the number of bottles in columns and rows by 1
            score += 100; //bonus points :(
            bottleArray.clear();
            bulletArray.clear();
            createBottle();
        }
    }
    
    //Create functions
    public void createBottle() {
        Random randy = new Random();
        int bottleRandomX = randy.nextInt(boardWidth-bottleWidth);
        Entity bottle = new Entity(bottleRandomX, bottleHeight+10, bottleWidth, bottleHeight, bottleImg);
        bottleArray.add(bottle);
        bottleCount = bottleArray.size();
    }
    
    //The if statements go here fsr
    public boolean detectCollision(Entity a, Entity b){
        return  a.x < b.x + b.width && //Leftmost thing checks rightmost other thing
                a.x + a.width > b.x && //Rightmost thing checks leftmost other thing
                a.y < b.y + b.height && //Highest thing checks Lowest other thing
                a.y + a.height > b.y; //Lowest thing checks Highest other thing
    }
    
    //Place the controls here and use @Override? Dont know why though since backspace isn't working.
    
    @Override
    public void actionPerformed(ActionEvent e){
        ticks();
        repaint();
        if (gameOver) {
            gameLoop.stop();
        }
    }
    
    @Override 
    public void keyPressed(KeyEvent e){}
    
    @Override
    public void keyTyped(KeyEvent e){}
    
    @Override
    public void keyReleased(KeyEvent e){
        if (gameOver) { //any key to restart
            cowboy.x = cowboyX;
            bulletArray.clear();
            bottleArray.clear();
            gameOver = false;
            score = 0;
            createBottle();
            gameLoop.start();
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT  && cowboy.x - cowboyVelocityX >= 0) {
            cowboy.x -= cowboyVelocityX; //move left one tile
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT  && cowboy.x + cowboyVelocityX + cowboy.width <= boardWidth) {
            cowboy.x += cowboyVelocityX; //move right one tile
        } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            //shoot bullet
            Entity bullet = new Entity(cowboy.x + cowboyWidth*15/32, cowboy.y, bulletWidth, bulletHeight, null);
            bulletArray.add(bullet);
            
        }
    }
    
}